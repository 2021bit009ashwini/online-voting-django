# ovs
Make sure you have installed (1)django2.2  (2)pillow  (3)django-widget-tweaks (pip install django-widget-tweaks)
 
